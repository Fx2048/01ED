#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Apr 21 19:53:25 2023

@author: nelsonenriquecastrozarate
"""

import random

"""
ALGORITMO DE EUCLIDES: función que calcula el máximo común divisor según el algoritmo de Euclides
"""
def algoritmo_euclides(a, b):
    if b == 0:
        return a
    elif a==0:
        return b
    else:
        return algoritmo_euclides(b % a,a)

"""
INVERSO MULTIPLICATIVO: función que me calcula el inverso multiplicativo
"""
def inverso_multiplicativo(e, phi):
    d = 0
    x1 = 0
    x2 = 1
    y1 = 1
    temp_phi = phi

    while e > 0:
        temp1 = temp_phi//e
        temp2 = temp_phi - temp1 * e
        temp_phi = e
        e = temp2

        x = x2 - temp1 * x1
        y = d - temp1 * y1

        x2 = x1
        x1 = x
        d = y1
        y1 = y

    if temp_phi == 1:
        return d + phi

"""
ES PRIMO: función calcula el valor de verdad si un número es primo
"""
def es_primo(num):
    if num == 2:
        return True
    if num < 2 or num % 2 == 0:
        return False
    for n in range(3, int(num**0.5)+2, 2):
        if num % n == 0:
            return False
    return True

"""
GENERAR LLAVES: función que devuelve una llave pública y otra privada a partir de dos números primos
"""
def generar_llaves(p, q):
    if not (es_primo(p) and es_primo(q)):
        raise ValueError("Ambos números deben ser primos.")
    elif p == q:
        raise ValueError("Los dos números ingresados no pueden ser iguales.")

    n = p * q

    phi = (p-1) * (q-1)

    e = random.randrange(1, phi)

    g = algoritmo_euclides(e, phi)
    while g != 1:
        e = random.randrange(1, phi)
        g = algoritmo_euclides(e, phi)

    d = inverso_multiplicativo(e, phi)

    return ((e, n), (d, n))

"""
ENCRIPTACIÓN: función que encripta un mensaje
"""
def encriptacion(llave_publica, mensaje):
    key, n = llave_publica
    msj_encriptado = [(ord(char) ** key) % n for char in mensaje]
    return msj_encriptado

"""
DECRIPTACIÓN: función que desencripta un mensaje
"""
def decriptacion(llave_privada, msj_encriptado):
    key, n = llave_privada
    msj = [chr((char ** key) % n) for char in msj_encriptado]
    return ''.join(msj)

"""
SCRIPT PRINCIPAL
"""
if __name__ == '__main__':
    p = int(input("Ingrese un número primo (p): "))
    q = int(input("Ingrese otro número primo (q): "))
    publico, privado = generar_llaves(p, q)
    print("Llave publica: ", publico)
    print("Llave privada: ", privado)
    mensaje = input("Ingrese un mensaje a encriptar: ")
    mensaje_encriptado = encriptacion(publico, mensaje)
    print("Mensaje encriptado: ", ''.join(map(lambda x: str(x), mensaje_encriptado)))
    print("Mensaje desencriptado: ", decriptacion(privado, mensaje_encriptado))
    
    