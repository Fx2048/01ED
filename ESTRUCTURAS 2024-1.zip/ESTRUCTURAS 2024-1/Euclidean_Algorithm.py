#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Apr 14 23:19:57 2023

@author: nelsonenriquecastrozarate
"""
"""
ALGORITMO DE EUCLIDES
"""
def algoritmo_euclides(a, b):
    if b == 0:
        return a
    elif a==0:
        return b;
    else:
        return algoritmo_euclides(b, a % b)
"""
ALGORITMO DE COEFICIENTES DEL ALGORITMO DE EUCLIDES
Explicación: mcd(a, b) = mcd(b, a - bq)
                       = mcd(b, r)
                       = bx1 + ry1  ()
                       = bx1 + (a - bq)y1
                       = ay1 + b(x1 - qy1)
"""    
def algoritmo_coeficientes(a, b):
    if b == 0:
        return (1, 0)
    elif a==0:
        return (0,1)
    q, r = divmod(a, b)
    x1, y1 = algoritmo_coeficientes(b, r)
    return (y1, x1 - q*y1)

print(algoritmo_euclides(210,715))
print(algoritmo_coeficientes(210,715))